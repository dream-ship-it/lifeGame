"""
Created on 2022-08-30 15:16
@author: wateryear
"""

class GameTimer(object):
    def __init__(self, interval):
        self.interval = interval
        pass
